# RomVault Instructions

WARNING: Never move your ROM files into the ToSort folder, always use a copy. I am not responsible for the loss of files if this strongly suggested rule has not been respected.

Place the MiSTer Organize DATs in the DatRoot folder. Place copies of your ROMs in the ToSort folder. Open ROMVault38.exe. Click Update DATs, click Scan ROMs, click Find Fixes, click Fix ROMs. Look in the RomRoot folder for your sorted ROMs.

The settings are already set up, including the MAME and HBMAME rules shown in the _IMPORTANT SETTINGS folder. RomVault 3.8 reads them from config\RomVault3cfg.xml. The copy of RomVault3cfg.xml next to ROMVault38.exe is the same file, kept for older RomVault versions and for RetroNAS.
