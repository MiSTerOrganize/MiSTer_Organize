# RomVault Instructions

WARNING: Never move your ROM files into the ToSort folder, always use a copy. I am not responsible for the loss of files if this strongly suggested rule has not been respected.

Place the MiSTer_Console DAT in DatRoot folder. Place your ROMs in ToSort folder. Open the RomVault application. Click Update DATs, click Scan ROMs, click Find Fixes, click Fix ROMs. Look in RomRoot folder for your sorted ROMs.